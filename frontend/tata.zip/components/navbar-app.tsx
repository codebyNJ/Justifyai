"use client"

import SiteNavbar from "@/components/site-navbar"

export default function NavbarApp() {
  return <SiteNavbar />
}
